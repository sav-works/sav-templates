# 📚 SavPrompt Pro — 200+ AI Business Prompts — Prompt Index

> **200 prompts** across **6 categories** | Bilingual EN/AR | Variables in `[brackets]`

---

## 📱 Section 1: Content Marketing — 50 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `CM01` | Write a 7-day Instagram carousel series about `[topic]`. Each day should cover one... | ✓ |
| 2 | `CM02` | Create a 30-day LinkedIn content calendar for a `[industry]` professional. Include... | ✓ |
| 3 | `CM03` | Write a 1500-word SEO-optimized blog post titled '`[blog title]`'. Target keyword:... | — |
| 4 | `CM04` | Create 5 clickbait headline variations for a blog post about `[topic]`. Each headl... | — |
| 5 | `CM05` | Write a 10-email welcome sequence for `[business name]` targeting `[audience person... | — |
| 6 | `CM06` | Generate 20 Twitter/X thread ideas for `[niche]`. Each idea should have a clickbai... | — |
| 7 | `CM07` | Write a Facebook ad copy for `[product/service]`. Format: Primary text (under 125... | — |
| 8 | `CM08` | Create 3 variations of a YouTube video script for a `[channel niche]` video titled... | — |
| 9 | `CM09` | Write an Instagram caption for a `[product/service]` launch. Length: 150-220 chars... | — |
| 10 | `CM10` | Design a content repurposing strategy for a 2000-word blog post titled '`[blog ti... | — |
| 11 | `CM11` | Write a Google Ads responsive search ad with 15 headlines and 4 descriptions for... | — |
| 12 | `CM12` | Create an email nurturing sequence for leads who downloaded `[lead magnet]`. Seque... | — |
| 13 | `CM13` | Write a TikTok script (max 60 seconds) for a viral video about `[topic]`. Include:... | — |
| 14 | `CM14` | Generate 10 email subject lines for a promotional campaign about `[offer]`. Use th... | — |
| 15 | `CM15` | Write a press release for `[company name]` announcing `[news/launch]`. Follow AP sty... | — |
| 16 | `CM16` | Create a 12-month content pillar strategy for a `[industry]` brand. Identify 4 con... | — |
| 17 | `CM17` | Write a 'About Us' page for `[company name]`. Format: Brand origin story (150 word... | — |
| 18 | `CM18` | Generate 20 FAQ questions and answers for `[product/service]`. Cover: pricing, fea... | — |
| 19 | `CM19` | Write a LinkedIn article (800-1200 words) positioning `[your name]` as a thought l... | — |
| 20 | `CM20` | Create a monthly newsletter content calendar for `[business type]`. Include: 4 new... | — |
| 21 | `CM21` | Write a Pinterest pin description for `[blog post title]`. Format: SEO-rich title... | — |
| 22 | `CM22` | Generate 5 'About to launch' social media posts for `[product name]` pre-launch ph... | — |
| 23 | `CM23` | Write a case study template for `[company name]` featuring client `[client name]`. S... | — |
| 24 | `CM24` | Create a 'Link in Bio' landing page copy for an Instagram creator in `[niche]`. Se... | — |
| 25 | `CM25` | Write a podcast episode description for an episode titled '`[episode title]`'. For... | — |
| 26 | `CM26` | Generate a sponsored post for `[brand]` collaborating with `[influencer name]`. Plat... | — |
| 27 | `CM27` | Write 10 'Objection handling' social media captions for `[product/service]`. Each... | — |
| 28 | `CM28` | Create a content gap analysis report for `[competitor URL/name]`. List: 10 topics... | — |
| 29 | `CM29` | Write an abandoned cart email series (3 emails) for `[e-commerce store]`. Email 1:... | — |
| 30 | `CM30` | Generate 15 'Quote of the day' social media graphics for `[niche]`. Each quote sho... | — |
| 31 | `CM31` | Write a product launch email sequence (5 emails) for `[product name]`. E1: Teaser... | — |
| 32 | `CM32` | Create a 'Week in the Life' LinkedIn content series for `[profession]`. 5 posts (M... | — |
| 33 | `CM33` | Write 3 versions of a cold DM script for Instagram outreach. Goal: book a `[disco... | — |
| 34 | `CM34` | Design a pillar-cluster content model for `[main topic]`. Identify: 1 pillar page... | — |
| 35 | `CM35` | Generate a viral challenge idea for TikTok/Reels in `[niche]`. Include: Challenge... | — |
| 36 | `CM36` | Write an 'Unsubscribe page' copy for `[email newsletter]`. Goal: retain subscriber... | — |
| 37 | `CM37` | Create a user-generated content (UGC) campaign brief for `[brand]`. Campaign name:... | — |
| 38 | `CM38` | Write a 'Thank You' page copy for `[offer/lead magnet]`. Sections: Thank-you headl... | — |
| 39 | `CM39` | Generate 10 'Comparison post' ideas comparing `[your product/service]` vs `[competi... | — |
| 40 | `CM40` | Write a brand voice guide for `[company name]`. Sections: Brand personality (3-5 a... | — |
| 41 | `CM41` | Create a summary/cheat-sheet post for a complex topic in `[niche]`. Format: 'Topic... | — |
| 42 | `CM42` | Write a 'Reactivation' email for subscribers who haven't opened emails in `[X mon... | — |
| 43 | `CM43` | Generate 5 'Myth vs Fact' social media carousel ideas for `[industry]`. Each carou... | — |
| 44 | `CM44` | Write a sponsored newsletter placement pitch for `[newsletter name]`. Pitch to `[sp... | — |
| 45 | `CM45` | Create 20 'Storytime' Instagram Story ideas for `[brand/creator]`. Mix of: Behind-... | — |
| 46 | `CM46` | Write a landing page hero section for `[product/service]`. Elements: Headline (und... | — |
| 47 | `CM47` | Generate 10 'This or That' poll ideas for Instagram Stories in `[niche]`. Each pol... | — |
| 48 | `CM48` | Write a video ad script (60 seconds) for `[platform: YouTube/Facebook/TikTok]`. St... | — |
| 49 | `CM49` | Create an editorial style guide for `[blog/publication]`. Sections: Voice & tone,... | — |
| 50 | `CM50` | Write 10 'Story-selling' LinkedIn posts. Each post follows: Hook (problem/curios... | — |

## 📊 Section 2: Business Strategy — 30 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `BS01` | Conduct a SWOT analysis for `[business/startup name]` in the `[industry]` sector. Fo... | — |
| 2 | `BS02` | Write a one-page business plan for `[business idea]`. Sections: Executive Summary... | — |
| 3 | `BS03` | Create a competitor analysis report for `[your business]`. Analyze 3 direct compet... | — |
| 4 | `BS04` | Define a target market profile for `[product/service]`. Include: Demographics (age... | — |
| 5 | `BS05` | Design a lean canvas for `[business idea]`. Fill out all 9 blocks: Problem, Soluti... | — |
| 6 | `BS06` | Create a product-market fit survey for `[product]`. Include: 10 survey questions u... | — |
| 7 | `BS07` | Write a go-to-market (GTM) strategy for `[product launch]`. Sections: Target segme... | — |
| 8 | `BS08` | Perform a PESTLE analysis for `[industry]` in `[country/region]`. Analyze Political,... | — |
| 9 | `BS09` | Draft a mission, vision, and values statement for `[company name]`. Mission (what... | — |
| 10 | `BS10` | Create a pricing strategy document for `[product/service]`. Compare 3 pricing mode... | — |
| 11 | `BS11` | Write a 12-month strategic roadmap for `[business]`. Q1: Foundation (product, hiri... | — |
| 12 | `BS12` | Conduct a Jobs-to-Be-Done (JTBD) analysis for `[product]`. Identify: 3 main jobs c... | — |
| 13 | `BS13` | Generate a risk assessment matrix for `[business/project]`. List 10 potential risk... | — |
| 14 | `BS14` | Create a stakeholder mapping for `[project/organization]`. Quadrants: High power/H... | — |
| 15 | `BS15` | Write a business model canvas narrative for `[startup]`. Describe each of the 9 bu... | — |
| 16 | `BS16` | Design an OKR (Objectives & Key Results) framework for `[department/company]`. 3 o... | — |
| 17 | `BS17` | Perform a market sizing analysis for `[product]` in `[region]`. Top-down approach: T... | — |
| 18 | `BS18` | Write an elevator pitch for `[business/idea]`. 3 versions: 15 seconds, 30 seconds,... | — |
| 19 | `BS19` | Create a customer journey map for `[product/service]`. Stages: Awareness → Conside... | — |
| 20 | `BS20` | Generate a partnership strategy document for `[business]`. Identify 5 ideal partne... | — |
| 21 | `BS21` | Write a due diligence checklist for acquiring `[target company/asset]`. Categories... | — |
| 22 | `BS22` | Design a customer retention program for `[SaaS/business]`. Components: Onboarding... | — |
| 23 | `BS23` | Create a cash flow forecasting template for `[small business]`. Monthly projection... | — |
| 24 | `BS24` | Perform a Blue Ocean Strategy analysis for `[industry]`. Identify: Current competi... | — |
| 25 | `BS25` | Write a crisis communication plan for `[company]`. Sections: Crisis team roles, Ti... | — |
| 26 | `BS26` | Generate a hiring plan for a `[stage: seed/series A/growth]` startup. Roles to hir... | — |
| 27 | `BS27` | Create a unit economics analysis for `[subscription/product business]`. Calculate:... | — |
| 28 | `BS28` | Write an investor pitch deck outline (10 slides) for `[startup]`. Slide 1: Title +... | — |
| 29 | `BS29` | Design a quarterly business review (QBR) template for `[department]`. Sections: Hi... | — |
| 30 | `BS30` | Perform a 5 Whys root cause analysis for `[business problem]`. State the problem.... | — |

## 🌙 Section 3: Arabic Content — 40 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `AR01` | Write an Instagram caption in Gulf Arabic (Kuwaiti/Saudi dialect) promoting `[pro... | ✓ |
| 2 | `AR02` | Create 5 LinkedIn post ideas for a `[industry]` professional targeting the Saudi m... | ✓ |
| 3 | `AR03` | Write a Twitter/X thread in Arabic about `[topic]`. 8 tweets. Each tweet: max 280... | ✓ |
| 4 | `AR04` | Generate 10 email subject lines in Arabic for a marketing campaign in the MENA r... | ✓ |
| 5 | `AR05` | Write a complete Facebook ad for the Kuwaiti market. Format: Primary text (Arabi... | ✓ |
| 6 | `AR06` | Create a bilingual (English + Arabic) email announcing `[event/launch]` for an aud... | ✓ |
| 7 | `AR07` | Write a ChatGPT prompt in Arabic for generating social media content for a Kuwai... | ✓ |
| 8 | `AR08` | Generate 10 Arabic hashtag sets for `[industry]` targeting the Saudi market. Each... | ✓ |
| 9 | `AR09` | Write a blog post introduction in Arabic for a topic about `[business topic]`. Fir... | ✓ |
| 10 | `AR10` | Create a script for a 30-second YouTube ad in Arabic. Product: `[product]`. Tone:... | ✓ |
| 11 | `AR11` | Write a WhatsApp business broadcast message in Arabic for `[business]`. Purpose: a... | ✓ |
| 12 | `AR12` | Generate 5 Ramadan marketing campaign ideas for `[brand]`. Each idea: campaign nam... | ✓ |
| 13 | `AR13` | Write a customer testimonial request message in Arabic. Template for `[business t... | ✓ |
| 14 | `AR14` | Create a social media crisis response statement in Arabic for `[brand]`. Addressin... | ✓ |
| 15 | `AR15` | Write a 'Come back' (Win-back) email in Arabic for inactive customers. Subject l... | ✓ |
| 16 | `AR16` | Generate 10 'عرض اليوم' (Today's Offer) social media graphics copy for a Kuwaiti... | ✓ |
| 17 | `AR17` | Write a product description in Arabic for `[product]`. Format: Product name, Key f... | ✓ |
| 18 | `AR18` | Create a 'نبذة عني' (About Me) section for a LinkedIn profile in Arabic. Profess... | ✓ |
| 19 | `AR19` | Write a Google My Business post in Arabic for `[local business]`. Post type: `[offe... | ✓ |
| 20 | `AR20` | Generate 5 'سؤال وجواب' (Q&A) social media posts in Arabic for `[brand]`. Each: 1... | ✓ |
| 21 | `AR21` | Write a 'شكراً لكم' (Thank You) post in Arabic for `[number]` followers. Express g... | ✓ |
| 22 | `AR22` | Create a Arabic landing page structure for a `[service]` in Saudi Arabia. Sections... | ✓ |
| 23 | `AR23` | Write an SMS marketing message in Arabic for `[business]`. Purpose: flash sale. Ma... | ✓ |
| 24 | `AR24` | Generate 10 'قصة نجاح' (Success Story) templates for `[business]`. Each template:... | ✓ |
| 25 | `AR25` | Write a Arabic press release for a `[company]` achievement/event in Kuwait. Format... | ✓ |
| 26 | `AR26` | Create a 'Before vs After' social media post in Arabic for `[service/transformati... | ✓ |
| 27 | `AR27` | Write 10 Arabic 'Pick-up lines' or engaging hooks for TikTok/Reels content in `[n... | ✓ |
| 28 | `AR28` | Generate a pricing page FAQ in Arabic for `[SaaS/product]`. 10 Q&A pairs addressin... | ✓ |
| 29 | `AR29` | Write a 'عيد الأضحى' (Eid Al-Adha) marketing message for `[brand]`. Medium: `[Insta... | ✓ |
| 30 | `AR30` | Create a bilingual 'شروط وأحكام' (Terms & Conditions) simplified summary for `[se... | ✓ |
| 31 | `AR31` | Write a Instagram Reel script in Arabic (15 seconds) for a product demo. Product... | ✓ |
| 32 | `AR32` | Generate 5 'استفتاء' (Poll) ideas for Instagram Stories in Arabic. Topic: `[topic... | ✓ |
| 33 | `AR33` | Write a cold email template in Arabic for B2B outreach. Target: Saudi companies.... | ✓ |
| 34 | `AR34` | Create a 'لايف' (Live stream) promotion post in Arabic. Platform: `[TikTok/Instag... | ✓ |
| 35 | `AR35` | Write 3 versions of an Arabic bio for an Instagram business account. Business: `[... | ✓ |
| 36 | `AR36` | Generate a content repurposing workflow in Arabic. Transform one `[long-form cont... | ✓ |
| 37 | `AR37` | Write a 'جهزنا لكم' (We've prepared for you) countdown post for a `[product launc... | ✓ |
| 38 | `AR38` | Create a 'من نحن' (About Us) page in Arabic for a Kuwaiti startup. Sections: Fou... | ✓ |
| 39 | `AR39` | Write 5 Arabic CTAs (Calls-to-Action) variations for each stage of the buyer jou... | ✓ |
| 40 | `AR40` | Create a local SEO optimization checklist in Arabic for a business in `[Kuwait/Sa... | ✓ |

## 🔄 Section 4: Translation & Localization — 30 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `TL01` | Translate the following English marketing copy into Modern Standard Arabic suita... | ✓ |
| 2 | `TL02` | Translate and localize the following website homepage for the Saudi Arabian mark... | — |
| 3 | `TL03` | Adapt the following English social media post for the Kuwaiti dialect. Source: '... | — |
| 4 | `TL04` | Translate the following legal disclaimer from English to Arabic. Source: '`[legal... | — |
| 5 | `TL05` | Create a localization quality checklist for Arabic (MENA). Include: RTL layout v... | — |
| 6 | `TL06` | Translate and adapt the following email newsletter for UAE audience. Source: '`[E... | — |
| 7 | `TL07` | Localize the following mobile app UI text from English to Arabic. Items: `[list o... | — |
| 8 | `TL08` | Translate the following product description from Arabic to English for an intern... | — |
| 9 | `TL09` | Perform a tone adaptation on this English copy. Change from `[tone A: formal/prof... | — |
| 10 | `TL10` | Translate the following blog post title and meta description into Arabic for SEO... | — |
| 11 | `TL11` | Create a glossary of `[N]` marketing terms translated from English to Arabic with... | — |
| 12 | `TL12` | Localize the following video script (English to Arabic) for a YouTube ad. Mainta... | — |
| 13 | `TL13` | Translate and optimize the following Google Ads copy from English to Arabic. Hea... | — |
| 14 | `TL14` | Create a style guide for English-to-Arabic translation of `[brand]` content. Secti... | — |
| 15 | `TL15` | Translate the following customer support email from English to Arabic. Source: '... | — |
| 16 | `TL16` | Localize the following landing page for Ramadan campaign. Source: '`[English page... | — |
| 17 | `TL17` | Translate the following technical documentation from English to Arabic. Source:... | — |
| 18 | `TL18` | Create a bilingual (EN/AR) social media post from the following English brief. '... | — |
| 19 | `TL19` | Perform a localization audit for `[website URL]`. Check: Arabic language coverage... | — |
| 20 | `TL20` | Translate the following LinkedIn profile headline and summary from English to Ar... | — |
| 21 | `TL21` | Localize the following e-commerce product page for the Egyptian market. Source:... | — |
| 22 | `TL22` | Translate and create a comparative analysis of English vs Arabic versions of the... | — |
| 23 | `TL23` | Create a machine translation post-editing (MTPE) guide for Arabic. Rules: Top 10... | — |
| 24 | `TL24` | Translate the following podcast episode description from English to Arabic. Sour... | — |
| 25 | `TL25` | Localize the following SaaS pricing page for the Gulf market. Source: '`[English... | — |
| 26 | `TL26` | Translate the following job description from English to Arabic. Source: '`[Englis... | — |
| 27 | `TL27` | Create a back-translation QA test for the following Arabic translation. Arabic s... | — |
| 28 | `TL28` | Localize the following newsletter call-to-action buttons for Arabic audience. So... | — |
| 29 | `TL29` | Translate the following testimonial from a Kuwaiti customer (Arabic) to English... | — |
| 30 | `TL30` | Create a full localization workflow document for launching `[product]` in the Saud... | — |

## 💼 Section 5: Resume & Career — 25 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `RC01` | Optimize the following resume bullet points for ATS (Applicant Tracking System).... | — |
| 2 | `RC02` | Write a LinkedIn 'About' section for `[name]`, a `[current role]` targeting `[next ro... | — |
| 3 | `RC03` | Create a cover letter for `[your name]` applying to `[company name]` for `[position]`.... | — |
| 4 | `RC04` | Generate 10 'cold outreach' LinkedIn messages targeting hiring managers at `[targ... | — |
| 5 | `RC05` | Rewrite the following job experience section for a `[target industry]` pivot. Orig... | — |
| 6 | `RC06` | Create a skills matrix for `[job title]` resume. List: 15 technical skills + 10 so... | — |
| 7 | `RC07` | Write 5 'accomplishment statement' variations for each of the following responsi... | — |
| 8 | `RC08` | Generate a list of 20 behavioral interview questions for `[position]` with STAR-fo... | — |
| 9 | `RC09` | Perform an ATS keyword gap analysis. Job description: '`[paste JD]`'. My resume: '... | — |
| 10 | `RC10` | Create a 'Career Change' resume summary for someone moving from `[old field]` to `[... | — |
| 11 | `RC11` | Write a 'Thank you' follow-up email after a job interview at `[company]`. Position... | — |
| 12 | `RC12` | Generate 10 'Open to Work' LinkedIn post ideas for `[profession]`. Each post: hook... | — |
| 13 | `RC13` | Rewrite resume for a different country's format. Current country format: `[countr... | — |
| 14 | `RC14` | Create a portfolio project description template for `[field: design/engineering/m... | — |
| 15 | `RC15` | Write a negotiation script for a job offer at `[company]`. Position: `[position]`. O... | — |
| 16 | `RC16` | Generate 5 'About Me' personal website copy options for `[name]`, a `[profession]`.... | — |
| 17 | `RC17` | Create a 30-60-90 day plan for a new `[position]` at `[company]`. 30 days: Learn (sy... | — |
| 18 | `RC18` | Write a LinkedIn recommendation for `[colleague name]`. Your relationship: `[how yo... | — |
| 19 | `RC19` | Generate 10 'Follow-up' email templates after submitting a job application. Situ... | — |
| 20 | `RC20` | Create a 'Skills-Based Resume' format for someone with gaps in employment. Focus... | — |
| 21 | `RC21` | Write 3 versions of a resume headline/tagline for `[name]`. Version 1: '`[role]` spe... | — |
| 22 | `RC22` | Generate a networking event introduction script (60-second 'elevator pitch') for... | — |
| 23 | `RC23` | Create a 'Side Projects' resume section that converts hobbies into professional... | — |
| 24 | `RC24` | Write a salary research report for `[position]` in `[city/country]`. Compile: Averag... | — |
| 25 | `RC25` | Generate a 'Pre-interview research' checklist for `[company name]`. Items: Company... | — |

## 💰 Section 6: Sales & Marketing — 25 Prompts

| # | ID | Prompt Summary | Arabic |
|---|----|---------------|--------|
| 1 | `SM01` | Write a cold email sequence (5 emails) for B2B outreach. Target: `[title]` at `[com... | — |
| 2 | `SM02` | Create a sales objection handling script for `[product/service]`. Address 7 common... | — |
| 3 | `SM03` | Write 5 product description variations for `[product]`. Variation types: Feature-f... | — |
| 4 | `SM04` | Create a pricing strategy proposal for `[product/service]`. Models: Freemium, Tier... | — |
| 5 | `SM05` | Write a sales page for `[product/service]`. Sections: Hero (headline + subheadline... | — |
| 6 | `SM06` | Generate 10 'cold call' opening scripts for `[product/service]`. Each: under 30 se... | — |
| 7 | `SM07` | Create a customer persona card template for `[product]`. Fields: Name (fictional),... | — |
| 8 | `SM08` | Write a 'Value Proposition Canvas' for `[product]`. Customer Profile: Customer job... | — |
| 9 | `SM09` | Create a referral program copy for `[business]`. Sections: Program name, How it wo... | — |
| 10 | `SM10` | Generate 10 'Limited time offer' email subject lines for `[offer]`. Techniques: Sc... | — |
| 11 | `SM11` | Write a sales proposal template for `[service]`. Sections: Executive summary, Unde... | — |
| 12 | `SM12` | Create a 'Feature → Benefit → Emotional Benefit' conversion table for `[product]`.... | — |
| 13 | `SM13` | Write 5 'Follow-up' email templates after a sales call. Situations: No response... | — |
| 14 | `SM14` | Design a sales pipeline stages document for `[business type]`. Stages: Lead → MQL... | — |
| 15 | `SM15` | Create a 'Battle Card' for competing against `[competitor name]`. Sections: Compet... | — |
| 16 | `SM16` | Write 3 'Upsell' email templates for existing customers of `[product]`. Customer s... | — |
| 17 | `SM17` | Generate a lead qualification (BANT) script for sales calls. Script questions fo... | — |
| 18 | `SM18` | Write a 'Product Launch' landing page for `[product]`. Elements: Pre-launch teaser... | — |
| 19 | `SM19` | Create a social selling guide for `[platform: LinkedIn/Twitter]` targeting `[indust... | — |
| 20 | `SM20` | Write a 'Re-engagement' campaign for lost leads (cold after `[X]` months). 3-email... | — |
| 21 | `SM21` | Create a 'Product Comparison' page copy. Compare `[your product]` vs `[competitor]`.... | — |
| 22 | `SM22` | Write a 'Customer pain point' discovery call script. 15-minute call. Structure:... | — |
| 23 | `SM23` | Generate 10 'Guarantee' statements for `[product/service]`. Types: Money-back, Sat... | — |
| 24 | `SM24` | Create a cross-selling strategy for `[product category]` in `[e-commerce/retail]`. I... | — |
| 25 | `SM25` | Write a 'Summer Sale' campaign strategy document. Product: `[product]`. Timeline:... | — |

---

_Generated by SavPrompt Pro | $19 | sav-templates.com_